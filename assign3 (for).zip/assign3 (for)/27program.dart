void main() {
  int num = 12;
  int sum = 1;
  for (int i = 1; i <= 10; i++) {
    sum = num * i;
    print("$sum");
  }
}
