void main() {
  for (int x = 1; x <= 100; x++) {
    print(x);
  }
}
