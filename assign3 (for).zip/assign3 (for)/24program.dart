void main() {
  for (int x = 2; x <= 100; x++) {
    if (x % 2 == 0) {
      print(x);
    }
  }
}
