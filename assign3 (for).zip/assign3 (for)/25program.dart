void main() {
  for (num x = 1; x <= 50; x++)
    if (x % 2!= 0 ) {
      print(x);
    }
}
