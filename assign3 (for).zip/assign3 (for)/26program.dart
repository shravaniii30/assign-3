void main() {
  for (int x = 100; x >= 1; x--) {
    print(x);
  }
}
