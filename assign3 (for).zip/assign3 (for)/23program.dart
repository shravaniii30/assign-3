void main() {
  int x = 10;
  for (x = 100; x <= 110; x++) {
    print(x);
  }
}
