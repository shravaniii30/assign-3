void main() {
  int num = 12;
  int sum = 1;
  for (int i = 10; i >= 1; i--) {
    sum = num * i;
    print("$sum");
  }
}