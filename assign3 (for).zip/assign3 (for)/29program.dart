void main() {
  int sum = 1;
  for (int x = 1; x <= 10; x++) {
    sum = x * sum;
    print("$sum");
  }
}
